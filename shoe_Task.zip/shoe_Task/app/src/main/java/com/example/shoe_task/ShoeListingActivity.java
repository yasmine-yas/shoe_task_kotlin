package com.example.shoe_task;

import android.app.Activity;

public class ShoeListingActivity extends Activity {
}
