package com.example.shoe_task

import android.os.Parcelable


data class Shoe (var name: String , var size: Double , var company: String, var description: String,
    val image: List<String> = mutableListOf()):Parcelable
